---
title: Qwen3-30B-A3B (MoE) tp=4 run config
tags: [tco, results, qwen3-30b-a3b, moe, v6e, tp4]
date: 2026-06-10
---

# Run: Qwen3-30B-A3B (MoE), tp=4, 4× v6e

复现用本目录 `stage_bench.sh` + `launch_30ba3b.sh`。

## 硬件 / 软件
- VM `mamba-v6e-4`(v6e-4, us-east1-d),spot。**用全部 4 chips(tp=4)**。
- 栈: vLLM-TPU `tpu-inference` **0.20.0**,Python 3.12。
- 模型: **Qwen/Qwen3-30B-A3B**(MoE,激活 ~3B / 总 30B,标准注意力,**非 GDN**)。Apache 2.0,非 gated。
  - 增量续传下载(`dl_cache.sh`)到平铺目录 `~/models/Qwen3-30B-A3B`,边下边 `gsutil rsync` 到 `gs://medusa-experiments/model-cache/staging/Qwen3-30B-A3B`(抗抢占续传)。

## 启动
```bash
MODEL=$HOME/models/Qwen3-30B-A3B TAG=Qwen3-30B-A3B-tp4 TP=4 GDN=0 GMU=0.8 MBT=8192 \
  PREFILL_CTXS="512 1024 2048 4096 8192" DECODE_CTXS="1024 4096" DECODE_BS="1 4 16 64" E2E_RATES="" \
  bash stage_bench.sh
```

## 关键配置
- **GDN=0**(标准注意力)→ 无 4B 那种 state-gather 限制,**MBT=8192 prefill 到 8192 不被 chunk**(干净)。
- **KV = fp8_e5m2**(TPU 默认)。GMU=0.8。
- e2e 本轮跳过(E2E_RATES 空)——先拿 prefill+decode,e2e 待按容量配 rate 单独跑。

## 结果(prefill 5 + decode 7;见 summary.txt）

**PREFILL** tok/s = ctx/p50_ttft:512→14620, 1024→20090, 2048→24375, 4096→**26062**, 8192→25767。
**DECODE** agg = bs×1000/p50_tpot:
- ctx=1024: 143 / 456 / 1071 / **1330**(bs 1/4/16/64)
- ctx=4096: 143 / 411 / 718 / —(bs 1/4/16；**b64 缺**)

## 与 Qwen3.5-4B tp=1 对比（headline）
| 指标 | 4B tp=1 | 30B-A3B tp=4 |
|------|---------|--------------|
| prefill 峰值 tok/s | ~4176(MBT=2048 chunk 封顶) | **26062**(MBT=8192 不 chunk) |
| decode agg @ctx1024 bs64 | 795 | **1330** |
| decode TPOT @bs1 | 10.7ms | **7.0ms** |
MoE 激活只 3B → decode 极快(TPOT 7ms);4 卡 + 无 chunk 限制 → prefill 高 6×。

## ⚠️ 数据完整度 / 缺口
- **缺 decode ctx=4096 bs=64**:30B tp=4 server 编译 ~5min，而本日 us-east1-d spot 抢占窗口比编译还短，该点反复够不着。且它几乎必撞 KV 容量上限(同 4B 的 4096 b64 = artifact，信息量最低)，故**认 7/8 decode 为完整**，不再空耗 spot cycle。
- **无 e2e**(本轮跳过)。
- 本 run 跨 **5+ 次 spot 抢占**完成:增量续传下载(rsync staging)+ supervisor 自动重建续跑(`supervisor_30ba3b.sh`)+ stage_bench done_point 跳过已完成点。详见 memory/lessons/tco-bench-spot-ops.md。

相关:[[../Qwen3.5-4B-tp1/RUN]] · [[../../scenarios/08-moe-models]] · [[../../methodology/01-sweep-params]]

## E2E 补测(2026-06-11，独立 TAG Qwen3-30B-A3B-tp4-e2e）
ISL/OSL=1024/1024，n=30，rate {0.4, inf}（spot 抢占凶，缩到最少 rate 塞进窗口）：
| rate | req/s | out_tok/s | TTFT p50/p99 | TPOT p50/p99 | E2E p50 |
|------|-------|-----------|--------------|--------------|---------|
| 0.4 | 0.36 | 366 | 92/190ms | 9.2/10.1ms | 9.5s |
| inf | 1.27 | 1303 | 712/1092ms | 22.3/22.8ms | 23.6s |
单芯…全 tp=4：30B-A3B(MoE) 1024/1024 容量 ~1.27 req/s / 1303 out tok/s。
本 e2e 靠"增量 JAX 编译缓存(GCS) + TPU 释放 + 最少 rate"在 spot 反复抢占下跑通。e2e jsons: e2e_rate_0.4.json / e2e_rate_inf.json。
