---
title: Qwen3-32B (dense) tp=4 run config
tags: [tco, results, qwen3-32b, dense, v6e, tp4]
date: 2026-06-10
---

# Run: Qwen3-32B (dense), tp=4, 4× v6e

复现用本目录 `stage_bench.sh` + `launch_32b.sh`。

## 硬件 / 软件
- VM `mamba-v6e-4`(v6e-4, us-east1-d),spot,**4 chips(tp=4)**。
- 栈: vLLM-TPU `tpu-inference` **0.20.0**,Python 3.12。
- 模型: **Qwen/Qwen3-32B**(dense 32B,标准注意力,**非 GDN**)。Apache 2.0。
  - 增量续传下载到 `~/models/Qwen3-32B`，rsync staging `gs://medusa-experiments/model-cache/staging/Qwen3-32B`(86GB，含 .incomplete 分片)。

## 启动
```bash
MODEL=$HOME/models/Qwen3-32B TAG=Qwen3-32B-tp4 TP=4 GDN=0 GMU=0.8 MBT=8192 \
  PREFILL_CTXS="512 1024 2048 4096 8192" DECODE_CTXS="1024 4096" DECODE_BS="1 4 16 64" E2E_RATES="" \
  bash stage_bench.sh
```
KV=fp8_e5m2(TPU 默认)。GDN=0 → MBT=8192 prefill 不被 chunk。e2e 跳过。

## 结果(prefill 5 + decode 6;见 summary.txt）
**PREFILL** tok/s:512→13541, 1024→17772, 2048→19647, 4096→**19714**, 8192→17786。
**DECODE** agg = bs×1000/p50_tpot:
- ctx=1024: 56 / 220 / 715 / **1096**(bs 1/4/16/64)
- ctx=4096: 53 / 187 / —(bs 1/4；**b16/b64 缺**)

## ⚠️ 数据完整度
- **缺 decode ctx=4096 bs=16, bs=64**:32B tp=4 server 编译 ~5min > 本日 us-east1-d spot 抢占窗口，跨 5 cycle 仍够不着这两点。已有数据(prefill 全 + ctx1024 decode 全 + ctx4096 bs1/4)足以支撑 MoE-vs-dense 对比，**认 6/8 为完整**，不再空耗 spot。
- 无 e2e(本轮跳过)。
- 跨 5+ 次抢占完成(增量续传 + `supervisor_32b.sh`)。

## 三模型对比(headline，全 tp=4 except 4B）
| | Qwen3.5-4B tp=1 | Qwen3-30B-A3B tp=4 (MoE) | Qwen3-32B tp=4 (dense) |
|---|---|---|---|
| prefill 峰值 tok/s | 4176* | **26062** | 19714 |
| decode TPOT @bs1 | 10.7ms | **7.0ms** | 17.9ms |
| decode agg @ctx1024 bs64 | 795 | **1330** | 1096 |
\* 4B 受 MBT=2048 chunk 封顶，非硬件极限。

**结论**:同~30B 规模，**MoE(30B-A3B)decode 比 dense(32B)快 ~2.5×**(TPOT 7 vs 18ms，激活 3B vs 全 32B)，prefill 也高 ~30%。这是 [[../../scenarios/08-moe-models]] 要的 TPU MoE 差异化证据。

相关:[[../Qwen3.5-4B-tp1/RUN]] · [[../Qwen3-30B-A3B-tp4/RUN]] · [[../../scenarios/08-moe-models]]
