---
title: Qwen3.5-4B tp=1 run config
tags: [tco, results, qwen3.5-4b, v6e, tp1]
date: 2026-06-09
---

# Run: Qwen3.5-4B, tp=1, single v6e chip

复现这份结果用本目录的 `stage_bench.sh`（即跑这次的同一份 driver 副本）。

## 硬件 / 软件
- VM: `mamba-v6e-4`(v6e-4, us-east1-d, medusa-compute),spot。**只用 1 chip(tp=1)**。
- 栈: vLLM-TPU `tpu-inference` **0.20.0**(PyPI),lm_eval 0.4.12,Python 3.12。
- 模型: `Qwen/Qwen3.5-4B`(GCS model-cache `qwen35_4b_hf.tar`),GDN(Gated DeltaNet)架构。

## 启动命令
```bash
MBT=2048 TP=1 GMU=0.5 bash stage_bench.sh
# tmux 内运行；linger 需先单独 ssh enable（见 memory/lessons/tco-bench-spot-ops.md）
```

## 关键配置 / 受控变量
- **KV cache = fp8_e5m2**(TPU v6e 自动启用;对照 H100 公开数要 matched 精度)。
- **MBT=2048**:tp=1 下 GDN state-gather 临时量 `f32[MBT,32,128,128]` 高 MBT 会 OOM。
  → prefill ctx>2048 走 **chunked prefill**(有效 matmul 钉在 2048),所以 prefill tok/s 在 ctx≥2048 压平到 ~4176。干净的长-context prefill 需 tp=4 高 MBT 或换全注意力模型。
- 多模态关闭(`--limit-mm-per-prompt image=0,video=0`)拆掉 GDN 的 MBT≥16384 地板。
- `--no-enable-prefix-caching`(每请求真做 prefill);`--ignore-eos`(decode 固定长度)。
- `--num-warmups` 每点排除 TPU 编译(prefill warmup=2,decode warmup=bs,e2e warmup=8)。
- 采样: vllm bench serve 默认(未强制 temperature=0);只测吞吐/延迟,温度不影响。

## Sweep
- prefill: conc=1, out=1, ctx ∈ {512,1024,2048,4096,8192};tok/s = ctx/p50_ttft。
- decode: out=128, max-conc=bs, ctx ∈ {1024,4096} × bs ∈ {1,4,16,64};agg_decode = bs×1000/p50_tpot。
- e2e: ISL/OSL=1024/1024, rate ∈ {1,2,4,8,inf}, n=200。

## 抗抢占
- 每点结果推 `gs://medusa-experiments/tco-bench/Qwen3.5-4B-tp1/`;脚本 resume(`done_point` 跳过 GCS 已有点)。
- 本次因 spot 两次抢占分段完成;prefill 在第 2 次重建前已入 GCS,decode/e2e 在 resume 后续跑。

## 文件
- `summary.txt` — 三段汇总表。
- `prefill_*.json` / `decode_*.json` / `e2e_*.json` — 每点 `vllm bench serve --save-result` 原始 JSON。
- `stage_bench.sh` — 本次 driver(复现用)。

## 结果解读 / 数据可信度（读表前必看）

**PREFILL**:prefill tok/s 在 ctx≥2048 饱和到 ~4176（512→1184, 1024→2265, 2048→4134, 4096/8192→~4170）。饱和是 **MBT=2048 的 chunked-prefill 上限**(有效 matmul 钉在 2048),不是模型/硬件极限。要看真实长-context prefill scaling 需 tp=4 放开 MBT。p50/p99 接近(warmup 排除编译)。

**DECODE**(主指标 = `agg_decode = bs×1000/p50_tpot`):
- ctx=1024(KV 小,batch 真并发):93 → 247 → 387 → **795** tok/s（bs 1/4/16/64),sublinear,接近带宽饱和。bs=16 的 p99 647ms 是一次性编译离群(bs=64 p99 97 干净 → 非系统性)。
- ctx=4096:93 → 158 → 188 → ⚠️。**`4096 bs=64` 的 agg 753 是 artifact,不可信**:它和 bs=16 数字几乎相同(TPOT 84.97 vs 84.98, req/s 都 0.86),说明 **KV 装不下 64 条并发,vLLM 把实际并发限到 ~16、其余排队**,公式乘了 64 故高估。**ctx=4096 decode 真实饱和 ≈ 188 tok/s（bs≈16 处 KV 撑满）**。
- 跨 context 对比:长 context 在 batch≥4 显著拖慢 decode(bs=16: 1024→387 vs 4096→188),即 KV-bandwidth-bound 效应([[../../scenarios/10-memory-bound-decode]])。bs=1 不受影响(权重带宽主导,KV 可忽略:93≈93)。

**E2E**(latency-vs-load,ISL/OSL=1024/1024):
- 单芯 tp=1 容量 ≈ **0.5 req/s**。未饱和区(rate 0.2–0.45)latency 平稳:TTFT p50 ~507ms、TPOT 12.3→13.8ms、E2E 13–15s,req/s 跟得上。这是有效的 latency-vs-load 曲线。
- ⚠️ **`rate=inf` 行不可信**:req/s 0.14 / out_tok 143 反而低于 rate=0.45,因 n=40 小样本 + 开环突发全部排队(p99 TTFT 220s)。**最大持续吞吐别用这行**;参考早先 200-prompt 的过载测(~515 out tok/s @ 0.5 req/s)或 decode 微基准(bs64@1024 = 795 agg)更靠谱。
- rate=0.2 的 p99 TTFT 33s 是一次性编译离群(0.3 起 p99 恢复正常 ~1.1s)。

**抢占史**:本 run 跨 3 次 spot 抢占完成。prefill+decode 在前 2 次重建前入 GCS,e2e 在第 3 次重建后用低 rate 重跑(初版 rate {1,2,4,8,inf} 全过载已废弃,见 git/memory）。所有点 resume 续跑,无重复计算。

相关:[[../../methodology/01-sweep-params]] · [[../../scenarios/12-official-perf-data]] · [[../../scenarios/10-memory-bound-decode]] · memory/lessons/tco-bench-spot-ops.md
