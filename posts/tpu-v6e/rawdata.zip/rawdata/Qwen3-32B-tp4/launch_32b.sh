#!/usr/bin/env bash
# Qwen3-32B (dense) tp=4 bench 参数。标准注意力(非 GDN)→ 放开 MBT；先 prefill+decode(e2e 跳过)。
export MODEL="$HOME/models/Qwen3-32B"
export TAG=Qwen3-32B-tp4
export TP=4 GDN=0 GMU=0.8 MBT=8192
export PREFILL_CTXS="512 1024 2048 4096 8192"
export DECODE_CTXS="1024 4096"
export DECODE_BS="1 4 16 64"
export E2E_RATES=""
exec bash "$HOME/stage_bench.sh"
