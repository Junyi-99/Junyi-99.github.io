#!/usr/bin/env bash
#
# stage_bench.sh — TCO TPU-vs-GPU 研究的单模型三-regime benchmark driver。
#
# 一次起 vllm serve、一次模型加载，对同一个 server 用 `vllm bench serve` 扫三段：
#   prefill — concurrency=1, output=1, sweep context → 取 p50 TTFT → prefill tok/s = ctx / ttft
#   decode  — 固定 context 取几档, sweep max-concurrency(=batch), output=DEC_OUT → output_throughput / TPOT
#   e2e     — 固定 ISL/OSL, sweep request-rate(Poisson 开环) → TTFT/TPOT/ITL/E2E 分位
#
# 为什么 serve 而不是 `vllm bench latency`：latency bench 每个 sweep 点重载模型 + 重新
# TPU 编译(每点数分钟)。serve 一次加载，每个新形状只编译一次。
#
# 抗 spot 抢占：每个点跑完立刻把 summary.txt + 该点 json 推到 GCS（GCS_OUT）。机器被
# preempt 重建后，已完成的点不用重跑——先 gsutil ls GCS_OUT 看跑到哪了。
#
# 排除 TPU 编译污染：每个 bench 点用 `--num-warmups`（一整波并发）做 warmup，编译开销
# 不进测量统计。这修了"短 run output_throughput 被首请求编译拖低"的假数。
#
# 关 prefix caching：保证每请求真做 prefill，不被缓存命中污染。
#
# 在 TPU VM 上跑，需先有 vllm_setup.py 装好的 venv（vllm-tpu / tpu_inference）。
#
# Tunables（环境变量）：
#   VLLM_VENV  venv (default $HOME/work-dir/vllm_env)   MODEL HF id (default Qwen/Qwen3.5-4B)
#   TAG 结果标签 (default basename(MODEL)-tp$TP)         TP (default 1)
#   GMU (default 0.5)   MBT (default 2048; tp=1 GDN 高 MBT 会 OOM)   MAXLEN (default 40960)
#   GDN 1=Qwen3.5 GDN(关多模态+GDN kernel) (default 1)   PORT (default 8000)
#   GCS_OUT 结果回传前缀 (default gs://medusa-experiments/tco-bench/$TAG)
#   PREFILL_CTXS (default "512 1024 2048 4096 8192")
#   DECODE_CTXS (default "1024 4096")   DECODE_BS (default "1 4 16 64")   DEC_OUT (default 128)
#   E2E_RATES (default "1 2 4 8 inf")   E2E_IN/E2E_OUT (default 1024/1024)   NUM_PROMPTS (default 200)
#   READY_TIMEOUT (default 1800)
set -uo pipefail

VENV="${VLLM_VENV:-$HOME/work-dir/vllm_env}"
[[ -f "$VENV/bin/activate" ]] || { echo "venv 缺失 $VENV (先跑 vllm_setup.py)" >&2; exit 1; }
# shellcheck disable=SC1091
source "$VENV/bin/activate"

MODEL="${MODEL:-Qwen/Qwen3.5-4B}"; TP="${TP:-1}"; GMU="${GMU:-0.5}"
MBT="${MBT:-2048}"; MAXLEN="${MAXLEN:-40960}"; GDN="${GDN:-1}"; PORT="${PORT:-8000}"
PREFILL_CTXS="${PREFILL_CTXS:-512 1024 2048 4096 8192}"
DECODE_CTXS="${DECODE_CTXS:-1024 4096}"; DECODE_BS="${DECODE_BS:-1 4 16 64}"; DEC_OUT="${DEC_OUT:-128}"
E2E_RATES="${E2E_RATES:-1 2 4 8 inf}"; E2E_IN="${E2E_IN:-1024}"; E2E_OUT="${E2E_OUT:-1024}"
NUM_PROMPTS="${NUM_PROMPTS:-200}"; READY_TIMEOUT="${READY_TIMEOUT:-1800}"

_deftag="$(basename "$MODEL")-tp${TP}"; TAG="${TAG:-$_deftag}"
GCS_OUT="${GCS_OUT:-gs://medusa-experiments/tco-bench/$TAG}"
BASE_URL="http://127.0.0.1:${PORT}"
RESULT_DIR="$HOME/tco_bench/${TAG}"; SERVER_LOG="$RESULT_DIR/server.log"; SUMMARY="$RESULT_DIR/summary.txt"
mkdir -p "$RESULT_DIR"
# resume：把 GCS 上已完成的点 json 拉回来，下面 done_point 会跳过它们（抗反复抢占）
gsutil -m -q cp "$GCS_OUT/*.json" "$RESULT_DIR/" 2>/dev/null || true
done_point(){ [[ -s "$RESULT_DIR/$1" ]] && python -c "import json,sys;json.load(open('$RESULT_DIR/$1'))" 2>/dev/null; }

export VLLM_XLA_CHECK_RECOMPILATION=0 SKIP_JAX_PRECOMPILE=1 HF_HUB_DOWNLOAD_TIMEOUT=60 HF_HUB_ENABLE_HF_TRANSFER=1
MM_FLAG=()
if [[ "$GDN" == "1" ]]; then
  export MODEL_IMPL_TYPE=vllm RAGGED_GATED_DELTA_RULE_IMPL=ragged_gated_delta_rule_chunked
  MM_FLAG=(--limit-mm-per-prompt '{"image":0,"video":0}')
fi

log(){ printf '\033[1;34m[stage-bench]\033[0m %s\n' "$*"; }
die(){ printf '\033[1;31m[stage-bench fail]\033[0m %s\n' "$*" >&2; exit 1; }
push(){ gsutil -q cp "$SUMMARY" "$GCS_OUT/summary.txt" 2>/dev/null || true; [[ -n "${1:-}" && -f "$RESULT_DIR/$1" ]] && gsutil -q cp "$RESULT_DIR/$1" "$GCS_OUT/$1" 2>/dev/null || true; }

SERVER_PID=""
cleanup(){ [[ -n "$SERVER_PID" ]] && kill -0 "$SERVER_PID" 2>/dev/null && { log "停 server pid=$SERVER_PID"; kill "$SERVER_PID" 2>/dev/null||true; wait "$SERVER_PID" 2>/dev/null||true; }; }
trap cleanup EXIT INT TERM

log "起 vllm serve: model=$MODEL tp=$TP gmu=$GMU mbt=$MBT maxlen=$MAXLEN gdn=$GDN port=$PORT  GCS_OUT=$GCS_OUT"
vllm serve "$MODEL" --tensor-parallel-size "$TP" --max-model-len "$MAXLEN" \
  --max-num-batched-tokens "$MBT" --gpu-memory-utilization "$GMU" --no-enable-prefix-caching \
  "${MM_FLAG[@]}" --port "$PORT" > "$SERVER_LOG" 2>&1 &
SERVER_PID=$!

log "等 server READY（最多 ${READY_TIMEOUT}s）…"
ready=0
for ((t=0; t<READY_TIMEOUT; t+=5)); do
  kill -0 "$SERVER_PID" 2>/dev/null || die "server 提前退出，看 $SERVER_LOG（常见 OOM）"
  curl -fsS "${BASE_URL}/health" >/dev/null 2>&1 && { ready=1; break; }
  sleep 5
done
[[ "$ready" == 1 ]] || die "等 ${READY_TIMEOUT}s 仍未 READY，看 $SERVER_LOG"
log "server READY ✓"

# run_point: in out conc rate nprompts warmups fname  → 失败返回非0
run_point(){
  local in="$1" out="$2" conc="$3" rate="$4" n="$5" wu="$6" fname="$7"
  local args=(--backend vllm --model "$MODEL" --base-url "$BASE_URL"
    --dataset-name random --random-input-len "$in" --random-output-len "$out"
    --num-prompts "$n" --num-warmups "$wu" --request-rate "$rate" --ignore-eos
    --percentile-metrics ttft,tpot,itl,e2el --metric-percentiles 50,99
    --save-result --result-dir "$RESULT_DIR" --result-filename "$fname")
  [[ "$conc" != "-" ]] && args+=(--max-concurrency "$conc")
  vllm bench serve "${args[@]}" > "$RESULT_DIR/${fname%.json}.log" 2>&1
}
jget(){ python - "$1" "$2" <<'PY'
import json,sys
try: print(f"{json.load(open(sys.argv[1])).get(sys.argv[2],float('nan')):.2f}")
except: print("NA")
PY
}

: > "$SUMMARY"
echo "# TCO stage bench  model=$MODEL tp=$TP gmu=$GMU mbt=$MBT kv=fp8(TPU默认)  vllm=$(python -c 'import vllm;print(vllm.__version__)' 2>/dev/null)  $(date -u +%FT%TZ)" | tee -a "$SUMMARY"; push

# ---- 1) PREFILL ----
{ echo; echo "## PREFILL (conc=1, out=1, warmup=2)"; echo "# ctx  p50_ttft_ms  p99_ttft_ms  prefill_tok_s"; } | tee -a "$SUMMARY"
for C in $PREFILL_CTXS; do
  log "prefill ctx=$C …"
  if done_point "prefill_${C}.json" || run_point "$C" 1 1 inf 12 2 "prefill_${C}.json"; then
    p50=$(jget "$RESULT_DIR/prefill_${C}.json" p50_ttft_ms); p99=$(jget "$RESULT_DIR/prefill_${C}.json" p99_ttft_ms)
    tps=$(python -c "print(f'{$C/($p50/1000):.1f}')" 2>/dev/null || echo NA)
    printf '%6s  %11s  %11s  %s\n' "$C" "$p50" "$p99" "$tps" | tee -a "$SUMMARY"
  else printf '%6s  FAILED (见 prefill_%s.log，常见 OOM)\n' "$C" "$C" | tee -a "$SUMMARY"; fi
  push "prefill_${C}.json"
done

# ---- 2) DECODE：warmup=一整波并发(bs)，排除编译；out_tok_s 现在干净 ----
{ echo; echo "## DECODE (out=$DEC_OUT, max-conc=bs, warmup=bs)"; echo "# ctx  bs  out_tok_s  p50_tpot_ms  p99_tpot_ms  agg_decode_tok_s(bs*1e3/tpot)  req_s"; } | tee -a "$SUMMARY"
for C in $DECODE_CTXS; do for B in $DECODE_BS; do
  n=$(( B*8 )); (( n<64 )) && n=64; wu=$B; (( wu<2 )) && wu=2
  log "decode ctx=$C bs=$B (n=$n wu=$wu) …"
  if done_point "decode_c${C}_b${B}.json" || run_point "$C" "$DEC_OUT" "$B" inf "$n" "$wu" "decode_c${C}_b${B}.json"; then
    f="$RESULT_DIR/decode_c${C}_b${B}.json"; ot=$(jget "$f" output_throughput); tp50=$(jget "$f" p50_tpot_ms); tp99=$(jget "$f" p99_tpot_ms); rs=$(jget "$f" request_throughput)
    agg=$(python -c "print(f'{$B*1000/$tp50:.1f}')" 2>/dev/null || echo NA)
    printf '%6s  %3s  %9s  %11s  %11s  %28s  %s\n' "$C" "$B" "$ot" "$tp50" "$tp99" "$agg" "$rs" | tee -a "$SUMMARY"
  else printf '%6s  %3s  FAILED (见 decode_c%s_b%s.log → 记为该 ctx 的 bs 上限)\n' "$C" "$B" "$C" "$B" | tee -a "$SUMMARY"; fi
  push "decode_c${C}_b${B}.json"
done; done

# ---- 3) E2E ----
{ echo; echo "## E2E (ISL/OSL=$E2E_IN/$E2E_OUT, n=$NUM_PROMPTS, warmup=8)"; echo "# rate  req_s  out_tok_s  TTFT(p50/p99 ms)  TPOT(p50/p99 ms)  E2E(p50/p99 ms)"; } | tee -a "$SUMMARY"
for R in $E2E_RATES; do
  log "e2e rate=$R …"
  if done_point "e2e_rate_${R}.json" || run_point "$E2E_IN" "$E2E_OUT" "-" "$R" "$NUM_PROMPTS" 8 "e2e_rate_${R}.json"; then
    f="$RESULT_DIR/e2e_rate_${R}.json"
    printf '%5s  %s  %s  %s/%s  %s/%s  %s/%s\n' "$R" "$(jget "$f" request_throughput)" "$(jget "$f" output_throughput)" \
      "$(jget "$f" p50_ttft_ms)" "$(jget "$f" p99_ttft_ms)" "$(jget "$f" p50_tpot_ms)" "$(jget "$f" p99_tpot_ms)" \
      "$(jget "$f" p50_e2el_ms)" "$(jget "$f" p99_e2el_ms)" | tee -a "$SUMMARY"
  else printf '%5s  FAILED (见 e2e_rate_%s.log)\n' "$R" "$R" | tee -a "$SUMMARY"; fi
  push "e2e_rate_${R}.json"
done

gsutil -q cp -r "$RESULT_DIR" "${GCS_OUT%/*}/" 2>/dev/null || true
log "完成。汇总：$SUMMARY （已推 $GCS_OUT）"
echo "###### STAGE BENCH DONE tag=$TAG ######"
cat "$SUMMARY"
