#!/usr/bin/env bash
# launch_30ba3b.sh — 固化 Qwen3-30B-A3B (MoE) tp=4 bench 的启动参数，给 stage_bench.sh。
# GDN=0（标准注意力，非 gated-delta-net）→ 无 MBT-gather 限制；先跑 prefill+decode（E2E_RATES 空跳过），
# 看完 decode 吞吐再按容量配 e2e rate 单独跑。
export MODEL="$HOME/models/Qwen3-30B-A3B"   # 平铺本地目录（dl_cache 下到这里）
export TAG=Qwen3-30B-A3B-tp4
export TP=4 GDN=0 GMU=0.8 MBT=8192
export PREFILL_CTXS="512 1024 2048 4096 8192"
export DECODE_CTXS="1024 4096"
export DECODE_BS="1 4 16 64"
export E2E_RATES=""
exec bash "$HOME/stage_bench.sh"
